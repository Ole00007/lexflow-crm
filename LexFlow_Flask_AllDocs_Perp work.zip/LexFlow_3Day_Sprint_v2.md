# LexFlow — Sprint Plan
**Updated: 12 May 2026**

---

## Sprint Goal

Ship AI Intake Classifier (P4) today + Lawyer Auto-Assignment (P3) tomorrow.
PostgreSQL deferred to post-demo (7–10 days).
Demo target: 2–3 lawyer friends. Focus: their pains = time, efficiency, missed urgency.

---

## DAY 1 — P4: AI Intake Classifier 🟣

### The Starting Prompt — paste into Claude Code

```
You are a senior Python engineer extending a Flask + SQLite app called LexFlow.

CONTEXT:
- app.py uses sqlite3 directly (no ORM)
- matters table: id, created_at, token, client_name, email, phone, company,
  practice_area, urgency, description, status, internal_notes
- POST /submit creates a matter, redirects to /status/<token>
- Admin at /admin and /admin/<matter_id>
- P7 dark theme applied — purple accent is #7C5CFC

TASK — AI Intake Classifier:

1. Add to init_db() matters table:
   ai_suggestion TEXT DEFAULT NULL
   ai_flag TEXT DEFAULT NULL
   ai_confidence INTEGER DEFAULT NULL
   ai_accepted INTEGER DEFAULT 0   (0=pending, 1=accepted, 2=dismissed)

2. After matter INSERT in POST /submit, call OpenAI API (gpt-4o-mini):
   - API key from env: os.getenv("OPENAI_API_KEY")
   - System prompt:
     "You are a legal intake triage assistant. Analyze the intake description
     and return ONLY valid JSON with these exact keys:
     urgency_override: one of Low / Medium / High / Critical
     risk_flag: max 12 words, plain language, specific to the description
     confidence: integer 0-100"
   - User message: the submitted description field
   - Wrap entirely in try/except — store NULL on any failure, never crash the form
   - Store: urgency_override → ai_suggestion, risk_flag → ai_flag, confidence → ai_confidence

3. admin.html — add AI column to matter list table:
   - ai_flag not NULL + ai_accepted==0: purple badge "⚡ AI Flag"
     style: background #7C5CFC; color white; border-radius 12px;
            padding 2px 10px; font-size 0.75rem; font-weight 500
   - ai_accepted==1: small green "✓ Accepted"
   - ai_accepted==2: small muted grey "Dismissed"
   - ai_flag is NULL: "—"

4. admin_matter.html — add AI Insights card (same card style as existing):
   - Title: "⚡ AI Intake Analysis" with #7C5CFC left-border accent
   - Row 1: Suggested urgency (value from ai_suggestion)
   - Row 2: Risk flag (value from ai_flag)
   - Row 3: Confidence — CSS-only % bar, color #7C5CFC, background #1E2A3A
   - Buttons (only if ai_accepted==0):
     "Accept suggestion" → POST /admin/<id>/ai-accept
     "Dismiss"          → POST /admin/<id>/ai-dismiss

5. New routes:
   POST /admin/<int:matter_id>/ai-accept  → UPDATE ai_accepted=1, redirect back
   POST /admin/<int:matter_id>/ai-dismiss → UPDATE ai_accepted=2, redirect back

RULES:
- Extend only. Do NOT rename columns, change form field names, or rewrite routes.
- Output only changed files: app.py, templates/admin.html, templates/admin_matter.html
- Add openai to requirements.txt
- Graceful fallback if OPENAI_API_KEY missing or call fails — NULL, never crash
- Keep all existing CSS classes and theme variables intact

VERIFY before outputting:
- POST /submit works without AI key (graceful NULL, no crash)
- Purple badge appears on admin list after intake with AI key set
- Accept/Dismiss updates DB and redirects back
- No horizontal scroll at 375px mobile
```

### Task Checklist
| # | Task | Time |
|---|---|---|
| 1 | Get key at platform.openai.com (free credits available for new accounts) | 10 min |
| 2 | Add OPENAI_API_KEY to Railway Variables (app service → Variables tab) | 5 min |
| 3 | Paste prompt above into Claude Code with your current app.py | 5 min |
| 4 | Copy returned files into project folder | 10 min |
| 5 | Run `python app.py` locally, submit test intake, check admin badge | 15 min |
| 6 | `git add . && git commit -m "P4: AI intake classifier" && git push origin main` | 5 min |
| 7 | Open Railway live URL — confirm badge appears | 10 min |

**Exit condition:** Submit intake on live URL → purple AI badge + risk flag in admin.

---

## DAY 2 — P3: Lawyer Auto-Assignment

### Tasks
| # | Task | Time |
|---|---|---|
| 1 | Add lawyers table to init_db() + seed 3 demo lawyers (name, email, practice_area) | 30 min |
| 2 | On POST /submit: SELECT lawyer WHERE practice_area matches → store lawyer_id on matter | 20 min |
| 3 | Show "Assigned to: [Name]" on admin matter detail card | 15 min |
| 4 | Resend email to lawyer: client name, area, urgency, description + AI flag if present | 25 min |
| 5 | Test: submit intake → correct lawyer gets email | 15 min |

**Exit condition:** Submit intake → correct lawyer receives instant email.

---

## SQLite Demo Protection (PostgreSQL paused)

Before every demo session:
1. Click "Load Demo Data" button already in your app — populates fresh realistic data instantly
2. Never push to main right before a demo — test on staging first
3. If Railway redeploys and wipes data mid-demo: reload demo data in 10 seconds, keep going

---

## 2-Minute Demo Script for Lawyer Friends

1. **Intake form** — type a real case description, mention urgency and a tricky detail
2. **Client status page** — "This is what your client sees. No phone call needed."
3. **Admin dashboard** — point at purple badge: *"AI flagged this as Critical before I read it"*
4. **Matter detail** — show AI Insights card: urgency + risk flag + confidence bar → click Accept
5. **(Day 2)** Show the lawyer assignment email arriving on your phone in real time

---

## What to Save From This Session

| Item | Where to save |
|---|---|
| LexFlow_Master_Plan_v2.md (downloaded) | LexFlow project folder on your PC |
| LexFlow_3Day_Sprint_v2.md (downloaded) | LexFlow project folder on your PC |
| The P4 Starting Prompt (copy from this doc) | Save as P4_AI_Classifier_Prompt.txt in project folder |
| OpenAI API key | Railway Variables only — never paste in code or messages |
| Railway DATABASE_URL (when you get it post-demo) | Railway Variables only |
| Your current app.py | Already in GitHub — confirm latest version is pushed |
