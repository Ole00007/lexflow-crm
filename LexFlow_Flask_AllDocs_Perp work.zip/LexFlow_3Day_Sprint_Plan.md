# LexFlow — 3-Day Sprint Plan
**Updated: 12 May 2026 | Previous plan: obsolete (replaced by this)**

---

## Sprint Goal
Ship a demo-ready MVP with persistent data, lawyer assignment, and one AI-powered feature. Ready for first outreach to Italian law firms by Day 3 end.

---

## DAY 1 — Fix the Foundation (Today, ~2 hrs remaining)

### Must-do
| # | Task | Time | Risk |
|---|---|---|---|
| 1 | Fix Railway Hobby billing (contact support or relog) | 15 min | LOW |
| 2 | Create Postgres service inside LexFlow project on Railway | 5 min | LOW |
| 3 | Copy DATABASE_URL → add to Railway app Variables (with ?sslmode=require) | 5 min | LOW |
| 4 | Add psycopg2-binary to requirements.txt | 5 min | LOW |
| 5 | Migrate sqlite3 queries in app.py to psycopg2 (AI-assisted) | 30 min | MEDIUM |
| 6 | Push to GitHub → verify Railway deploys without error | 10 min | LOW |
| 7 | Submit test form → redeploy → confirm data still there ✅ | 10 min | NONE |

**Day 1 exit condition:** Data persists after redeploy. The core bug is gone.

---

## DAY 2 — Lawyer Assignment (Most Needed Feature, ~3 hrs)

### What it is
When a client submits the intake form, the system automatically assigns the matter to the correct lawyer based on practice area. The lawyer receives an email instantly.

### Why it matters
- This is the #1 missing workflow in small Italian law firms today
- Clio Grow, Lawmatics, and MyCase all have this — but cost €100+/mo
- Directly reduces admin coordination overhead (partner manually forwards every intake)
- Makes your demo "sticky" — the partner sees real value in 30 seconds

### Tasks
| # | Task | Time |
|---|---|---|
| 1 | Add lawyers table to DB (id, name, email, practice_area) | 20 min |
| 2 | Seed 3 demo lawyers (one per practice area) | 10 min |
| 3 | On POST /submit: match practice_area → assign lawyer_id to matter | 20 min |
| 4 | Show "Assigned to: [Name]" on admin matter detail | 15 min |
| 5 | Resend email to assigned lawyer: client name, area, urgency, description | 20 min |
| 6 | Test full flow: intake → auto-assign → lawyer email received | 15 min |

**Day 2 exit condition:** Submit intake → correct lawyer gets email automatically.

---

## DAY 3 — AI Intake Classifier (Flashiest Feature, ~3 hrs)

### What it is
When a client submits the intake form, the AI reads the description and returns:
1. A suggested urgency level (override if different from client's self-assessment)
2. A risk flag ("mentions contract dispute — check conflict of interest")
3. A confidence score

This appears as a purple AI badge on the admin dashboard and matter detail.
Admin can accept or dismiss. Never shown to client.

### Why it is the flashiest realistic feature
- Visible in the first 5 seconds of a demo (badge on the dashboard)
- Solves a real pain: lawyers spend 10+ minutes reading every intake before triaging
- GDPR-safe: AI processes description only, no PII, no output to client
- Cost: ~$0.001 per intake with GPT-4o-mini or Claude Haiku
- Buildable in one session with a clear prompt

### Tasks
| # | Task | Time |
|---|---|---|
| 1 | Add ai_suggestion and ai_flag columns to matters table | 15 min |
| 2 | On POST /submit: call Claude Haiku or GPT-4o-mini with intake description | 30 min |
| 3 | Parse JSON response: urgency_override, risk_flag, confidence | 20 min |
| 4 | Store in DB, show purple AI badge on admin list and detail | 20 min |
| 5 | Add "Accept / Dismiss" button on matter detail (updates DB) | 20 min |
| 6 | Test: submit intake → AI badge appears → admin accepts suggestion | 15 min |

**Day 3 exit condition:** Submit intake → AI badge with risk flag appears in admin dashboard. Demo-ready.

---

## Feature Priority Table (for future backlog)

| Priority | Feature | Why | Effort |
|---|---|---|---|
| P1 ✅ | Intake + status + admin | Core MVP | Done |
| P2 🔄 | PostgreSQL persistence | Data survives deploys | Today |
| P3 📅 | Lawyer auto-assignment | #1 workflow pain | Day 2 |
| P4 📅 | AI intake classifier | Best demo feature | Day 3 |
| P5 | Admin login (password) | Security before real clients | Week 2 |
| P6 | Client document upload from status page | Self-service | Week 2 |
| P7 | Sales funnel email sequence | Growth | Week 3 |
| P8 | AI document triage (upload → extract deadlines) | Enterprise wedge | Month 2 |

---

## Reddit Launch (r/legaltech) — Post Day 3 End
- Screenshot: intake form → AI badge on admin → client status page
- Post title: "Built a client intake tracker for Italian law firms in 3 days — feedback welcome"
- Include live URL
- DO NOT post before Day 1 fix is confirmed (no SQLite data loss risk)
