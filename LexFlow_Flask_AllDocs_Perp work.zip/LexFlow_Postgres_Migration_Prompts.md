# LexFlow — SQLite → Railway PostgreSQL Migration Prompts

---

## PROMPT 1 — Replace SQLite with PostgreSQL in app.py
**Use in:** Claude Code or Cursor  
**When:** Step 5 of migration plan

```
You are a senior Flask developer.

Context:
- My app is `app.py` in the repo root
- It currently uses SQLite via SQLAlchemy with a hardcoded file path
- I am migrating to Railway PostgreSQL
- The new DATABASE_URL is already set as an environment variable on Railway
- Railway requires `?sslmode=require` appended to the URL

Task:
1. Replace the SQLite `SQLALCHEMY_DATABASE_URI` line with:
   `app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///lexflow.db')`
   (SQLite stays as local fallback only)
2. Ensure `import os` is present at the top
3. Do NOT change any model definitions, routes, or other logic
4. Show me only the changed lines with surrounding context (5 lines above/below each change)

File: app.py
```

---

## PROMPT 2 — Update requirements.txt for PostgreSQL
**Use in:** Claude Code, Cursor, or manual edit  
**When:** Step 4 of migration plan

```
You are helping me migrate a Python Flask app from SQLite to PostgreSQL.

My current requirements.txt is below. Add `psycopg2-binary` if it is not already present.
Do NOT change any other dependency or version.
Return the full updated requirements.txt only — no explanation.

[PASTE YOUR CURRENT requirements.txt HERE]
```

---

## PROMPT 3 — Debug: app won't connect to Railway PostgreSQL
**Use in:** Claude Code, PowerShell tutor, or Perplexity  
**When:** After deploy, if you see a DB connection error in Railway logs

```
My Flask app fails to connect to Railway PostgreSQL after migration.

Error from Railway logs:
[PASTE ERROR MESSAGE HERE]

Context:
- Stack: Flask + SQLAlchemy + psycopg2-binary
- Hosting: Railway
- DATABASE_URL is set in Railway environment variables
- sslmode=require is appended to the URL

Diagnose the root cause and give me:
1. The most likely cause (1 sentence)
2. The exact fix (code or config change)
3. How to verify it worked (1 command or check)
```

---

## PROMPT 4 — Verify data persists after redeploy
**Use in:** PowerShell / terminal or browser  
**When:** Step 9 of migration plan (critical test)

```
I migrated my Flask app from SQLite to Railway PostgreSQL.
I need to verify that data now persists across redeployments.

Give me a step-by-step manual test checklist:
1. How to submit a test record via the app UI
2. How to confirm it is stored in Railway Postgres (via Railway dashboard or psql)
3. How to trigger a redeploy on Railway
4. How to confirm the record still exists after redeploy

My app has:
- An intake form at /
- An admin dashboard at /admin
- A PostgreSQL service on Railway with DATABASE_URL set
```

---

## PROMPT 5 — Full migration audit after deploy
**Use in:** Perplexity Space / Claude  
**When:** After merge to main (production), as a final safety check

```
I just migrated my LexFlow MVP from SQLite to Railway PostgreSQL.

Please audit the following and flag any risks:

1. app.py database configuration (I will paste relevant section)
2. requirements.txt
3. Railway environment variables (I will describe what is set)

Check for:
- Any remaining hardcoded SQLite paths
- Missing sslmode=require
- psycopg2 vs psycopg2-binary (binary is correct for Railway)
- Any model or migration issue that could cause data loss
- Any local-only config that could break in production

Flag each issue as: CRITICAL / WARNING / INFO
```
