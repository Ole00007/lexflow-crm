# LexFlow MVP — Updated Master Plan
**Last updated: 12 May 2026 | Status: Active**

---

## ✅ DONE — What We Built (May 7–12)

| Feature | Status | Notes |
|---|---|---|
| Home page intake form | ✅ Done | Flask, all fields, file upload |
| Form submission + Resend email notification | ✅ Done | Working in production |
| Client status page (token-gated) | ✅ Done | GDPR-safe, no PII exposed |
| Admin dashboard (matter list) | ✅ Done | Full table, status badges |
| Admin matter detail | ✅ Done | 4-section view, status update |
| File uploads (PDF, Word, images) | ✅ Done | werkzeug, local uploads/ folder |
| Load demo data (button + URL) | ✅ Done | For demos/screenshots |
| Premium dark/light UI (P7 polish) | ✅ Done | Inter font, token system, toggle |
| Deploy to Railway | ✅ Done | Live production URL |
| GitHub repo (main branch) | ✅ Done | Pushing from local via PowerShell |

---

## 🔧 IN PROGRESS — Infrastructure Fix

| Task | Status | Owner | ETA |
|---|---|---|---|
| Fix Railway Hobby billing (unlock Postgres creation) | 🔄 In progress | You | Today |
| Migrate SQLite → Railway PostgreSQL | ⏳ Blocked by above | You + AI | Today after billing fixed |
| Add DATABASE_URL env var to Railway app service | ⏳ Blocked by above | You | Today |
| Add psycopg2-binary to requirements.txt | ⏳ Ready to do | You | Today |
| Replace sqlite3 raw queries with psycopg2 in app.py | ⏳ Ready to do | You + AI | Today |
| Verify data persists after redeploy | ⏳ Ready to test | You | After migration |

---

## 🗓️ NEXT 3 DAYS — Feature Roadmap

### Day 1 (Today remaining): Persistence fix
- [ ] Fix Railway Hobby billing → Create Postgres service
- [ ] Copy DATABASE_URL → Add to Railway app Variables
- [ ] Migrate app.py from sqlite3 to psycopg2
- [ ] Push, deploy, verify data survives redeploy ← THE MILESTONE

### Day 2: Lawyer Assignment Feature (Most Needed)
- [ ] Add lawyers table (name, practice_area, email)
- [ ] Auto-assign intake to lawyer by practice_area match
- [ ] Show assigned lawyer on admin matter detail
- [ ] Trigger email to assigned lawyer (via Resend) on new intake
- [ ] Lawyer receives: client name, practice area, urgency, description

### Day 3: Flashy Demo Feature — AI Intake Classifier
- [ ] On form submit: call Claude API (or GPT-4o-mini) with intake description
- [ ] AI returns: urgency override, suggested practice area, 1-line risk flag
- [ ] Show AI badge on admin dashboard (purple badge per P7 design)
- [ ] Admin can accept or dismiss AI suggestion (one click)
- [ ] No AI output ever shown to client (GDPR + ethics compliance)

---

## 🛡️ PROTECTED — Never Touch
- migrations/ folder (if created)
- main branch (PRs only from staging)
- Production DATABASE_URL (never in code)
- Auth files (when added)

---

## 📊 Stack (Source of Truth)
| Layer | Technology |
|---|---|
| Backend | Python Flask |
| Database | Railway PostgreSQL (migrating to) |
| Email | Resend Python SDK |
| Hosting | Railway (app + DB) |
| Frontend | Jinja2 server-rendered HTML |
| UI | Custom CSS, Inter font, dark/light theme |
| Version control | GitHub (main = prod, staging = staging) |
