# LexFlow MVP — Master Plan
**Last updated: 12 May 2026 — Updated per session command**

---

## ✅ DONE — Built (May 7–12)

| Feature | Status | Notes |
|---|---|---|
| Home page intake form | ✅ Done | Flask, all fields, file upload |
| Form submission + Resend email notification | ✅ Done | Working in production |
| Client status page (token-gated) | ✅ Done | GDPR-safe, no PII exposed |
| Admin dashboard (matter list) | ✅ Done | Full table, status badges |
| Admin matter detail | ✅ Done | 4-section view, status update |
| File uploads (PDF, Word, images) | ✅ Done | werkzeug, local uploads/ folder |
| Load demo data (button + URL) | ✅ Done | For demos/screenshots |
| Premium dark/light UI (P7 polish) | ✅ Done | Inter font, token system, toggle |
| Deploy to Railway | ✅ Done | Live production URL |
| GitHub repo (main branch) | ✅ Done | Pushing from local via PowerShell |

---

## ⏸ PAUSED — PostgreSQL Migration (resume in 7–10 days)

**Decision 12 May 2026:** PostgreSQL migration paused until after demo to lawyer friends.
SQLite stays. Protect DB manually for demo window. Railway Hobby billing fix deferred.

| Task | Resume when |
|---|---|
| Fix Railway Hobby billing | After demo |
| Migrate SQLite → PostgreSQL | After demo |
| Add psycopg2-binary, migrate app.py | After demo |

---

## 🗓️ ACTIVE SPRINT — 2 Days

### TODAY — P4: AI Intake Classifier (The Hook)

Purple AI badge on admin dashboard after every intake.
Shows: urgency override + risk flag + confidence score.
Admin accepts or dismisses. Never shown to client. GDPR-safe.

| # | Task | Time |
|---|---|---|
| 1 | Get OpenAI API key → add as OPENAI_API_KEY in Railway Variables | 15 min |
| 2 | Add ai_suggestion, ai_flag, ai_confidence, ai_accepted columns to matters table | 15 min |
| 3 | On POST /submit: call gpt-4o-mini with description, parse JSON | 30 min |
| 4 | Store result in DB, graceful NULL fallback on failure | 10 min |
| 5 | Purple AI badge on admin list + AI Insights card on matter detail | 20 min |
| 6 | Accept / Dismiss buttons → two new POST routes | 15 min |
| 7 | Test full flow | 15 min |

**Exit condition:** Submit intake → purple AI badge + risk flag visible in admin.

### TOMORROW — P3: Lawyer Auto-Assignment

| # | Task | Time |
|---|---|---|
| 1 | Add lawyers table + seed 3 demo lawyers | 30 min |
| 2 | On POST /submit: match practice_area → assign lawyer_id | 20 min |
| 3 | Show assigned lawyer on admin matter detail | 15 min |
| 4 | Resend email to lawyer on new intake | 20 min |
| 5 | Test full flow | 15 min |

---

## 📋 Full Backlog

| Priority | Feature | Status | When |
|---|---|---|---|
| P1 | Intake + status + admin | ✅ Done | — |
| P2 | PostgreSQL persistence | ⏸ Paused | After demo |
| P3 | Lawyer auto-assignment | 📅 Tomorrow | Day 2 |
| P4 | AI intake classifier | 📅 Today | Day 1 |
| P5 | Admin login | Backlog | Week 2 |
| P6 | Client doc upload from status page | Backlog | Week 2 |
| P7 | Sales funnel email sequence | Backlog | Week 3 |
| P8 | AI document triage | Backlog | Month 2 |

---

## 🛡️ Protected

- SQLite DB file — do NOT wipe during demo window
- main branch — PRs only
- Production secrets — never in code

---

## 📊 Stack

| Layer | Tech | Note |
|---|---|---|
| Backend | Python Flask | — |
| Database | SQLite | ⚠️ Resets on redeploy — manual protection for demo |
| Email | Resend Python SDK | Working |
| AI | GPT-4o-mini (OpenAI) | Adding today for P4 |
| Hosting | Railway | Live |
| Frontend | Jinja2 + custom CSS | Dark/light theme, Inter font |
| Version control | GitHub | main=prod, staging=staging |

---

## 💡 Product Hook

> *"Like tracking a package — but for your legal matter."*

B2B focus: lawyer friends as first focus group.
Their pains: time, efficiency, reputation risk from missed urgency signals.
